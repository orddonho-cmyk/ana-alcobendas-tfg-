import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  AlertTriangle, ArrowRight, Bot, Check, ChevronRight, CircleHelp,
  ClipboardCheck, FileText, Gavel, History, Info, Mic, Paperclip,
  Send, ShieldCheck, UserRound, UsersRound, X
} from "lucide-react";
import "./styles.css";

const SESSION_ID = `ALC-2026-${Math.floor(100 + Math.random() * 900)}`;

const DEMO_CASE =
  "CASO FICTICIO DE DEMOSTRACIÓN: Deseo realizar una redistribución interior de tabiquería en vivienda situada en parcela urbana residencial de Alcobendas. No se modifican vigas ni pilares.";

const routes = {
  licencia: {
    title: "Licencia tradicional",
    short: "Control previo",
    color: "rose",
    prompt: "Deseo consultar los requisitos para una actuación con modificación de pilares maestros."
  },
  declaracion: {
    title: "Declaración responsable",
    short: "Control posterior",
    color: "emerald",
    prompt: "Deseo consultar la vía de Declaración Responsable para redistribuir la tabiquería interior de una vivienda sin afectar a elementos estructurales."
  },
  comunicacion: {
    title: "Comunicación previa",
    short: "Puesta en conocimiento",
    color: "blue",
    prompt: "Deseo consultar la vía de Comunicación Previa para trabajos simples de pintura interior y cambio de solado."
  }
};

function classify(text) {
  const t = text.toLowerCase();

  const structure =
    ["muro", "pilar", "viga", "forjado", "estructura", "fachada"]
      .some(x => t.includes(x));

  const explicitNoStructure =
    ["sin modificar", "sin tocar", "no se modifican", "no afecta", "no se modifica"]
      .some(x => t.includes(x));

  const protection =
    ["protegido", "bic", "catalogado", "patrimonio", "no protegido"]
      .some(x => t.includes(x));

  if (!structure &&
      !["pintar", "solado", "azulejo", "alicatado", "mantenimiento"].some(x => t.includes(x))) {
    return {
      status: "insufficient",
      title: "Necesito un dato más",
      confidence: null,
      reason: "El árbol de decisión necesita conocer la posible afección estructural y la situación patrimonial del inmueble.",
      checks: [
        ["Estructura", "Pendiente de aclarar", "warning"],
        ["Protección patrimonial", "Pendiente de aclarar", "warning"]
      ]
    };
  }

  const major =
    t.includes("nueva planta") ||
    t.includes("ampliación") ||
    (structure && !explicitNoStructure);

  const simple =
    ["pintar", "solado", "azulejo", "alicatado", "mantenimiento"]
      .some(x => t.includes(x));

  if (major) {
    return {
      status: "result",
      type: "licencia",
      title: "Licencia tradicional",
      confidence: 91,
      reason: "La descripción incorpora una actuación que puede afectar a elementos estructurales o encajar en una obra de mayor entidad.",
      checks: [
        ["Estructura", "Revisión técnica requerida", "danger"],
        ["Protección patrimonial", protection ? "Revisión de catálogo" : "Pendiente de verificación", "warning"],
        ["Catastro / PGOU", "No verificado en este prototipo", "neutral"]
      ]
    };
  }

  if (simple) {
    return {
      status: "result",
      type: "comunicacion",
      title: "Comunicación previa",
      confidence: 94,
      reason: "La descripción contiene una actuación de conservación o acabado sencillo que el prototipo clasifica en esta vía.",
      checks: [
        ["Tipo de actuación", "Trabajo sencillo identificado", "good"],
        ["Estructura", "Sin afección indicada", "good"],
        ["Protección patrimonial", "Pendiente de verificación", "warning"]
      ]
    };
  }

  return {
    status: "result",
    type: "declaracion",
    title: "Declaración responsable",
    confidence: 86,
    reason: "La descripción apunta a una reforma interior sin modificación estructural. La situación patrimonial sigue pendiente de verificación.",
    checks: [
      ["Estructura", "Sin afección declarada", "good"],
      ["Protección patrimonial", "Pendiente de verificación", "warning"],
      ["Catastro / PGOU", "No verificado en este prototipo", "neutral"]
    ]
  };
}

function App() {
  const [officer, setOfficer] = useState(false);
  const [messages, setMessages] = useState([
    {
      who: "ana",
      text: "Hola. Soy ANA, el sistema de orientación urbanística asistida.",
      extra: "Describe la actuación que quieres analizar. Si conoces la afección estructural o la protección del inmueble, indícalo."
    }
  ]);
  const [input, setInput] = useState("");
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);
  const [audit, setAudit] = useState([]);

  const send = (text = input) => {
    const value = text.trim();
    if (!value && !file) return;

    const attachment = file?.name;
    setMessages(m => [...m, { who: "user", text: value || "Documento adjunto", attachment }]);
    setInput("");

    const analysis = classify(value);
    setTimeout(() => {
      setResult(analysis);
      setMessages(m => [...m, { who: "ana", result: analysis }]);
    }, 280);
  };

  const addAudit = (action, reason) => {
    setAudit(a => [{
      action,
      reason,
      time: new Date().toLocaleString("es-ES", { hour: "2-digit", minute: "2-digit" }),
      session: SESSION_ID
    }, ...a]);
  };

  const loadDemo = () => {
    setInput(DEMO_CASE);
    setFile({ name: "Memoria_Simulada_Ficticia_TFG.pdf", size: "180 KB" });
  };

  const selectRoute = (type) => {
    setInput(routes[type].prompt);
    document.getElementById("composer")?.focus();
  };

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark">A</div>
          <div>
            <div className="brand-line">
              <strong>ANA</strong>
              <span>PROTOTIPO TFG</span>
            </div>
            <small>Orientación urbanística asistida · Ayuntamiento de Alcobendas</small>
          </div>
        </div>

        <div className="top-actions">
          <span className="status"><i /> Motor de decisión activo</span>
          <button className="mode-button" onClick={() => setOfficer(!officer)}>
            {officer ? <UsersRound size={15}/> : <UserRound size={15}/>}
            {officer ? "Empleado público" : "Ciudadano"}
          </button>
        </div>
      </header>

      <div className="notice">
        <AlertTriangle size={15}/>
        <span><b>Demostrador conceptual.</b> ANA ofrece orientación preliminar y no sustituye una resolución administrativa.</span>
        <code>{SESSION_ID}</code>
      </div>

      <main className="workspace">
        <aside className="sidebar">
          <section className="hero-card">
            <div className="eyebrow">EXPEDIENTE PILOTO · FICTICIO</div>
            <h1>Analiza una actuación urbanística.</h1>
            <p>Recorre el árbol de decisión y descubre qué vía podría corresponder.</p>
            <button className="primary light" onClick={loadDemo}>
              Cargar caso de demostración <ArrowRight size={16}/>
            </button>
          </section>

          <section className="panel">
            <div className="panel-title">
              <div>
                <small>MARCO DE DECISIÓN</small>
                <h2>Vías de tramitación</h2>
              </div>
              <Gavel size={18}/>
            </div>

            {Object.entries(routes).map(([key, route], i) => (
              <button className={`route route-${route.color}`} key={key} onClick={() => selectRoute(key)}>
                <span className="route-number">0{i + 1}</span>
                <span className="route-copy">
                  <b>{route.title}</b>
                  <small>{route.short}</small>
                </span>
                <ChevronRight size={16}/>
              </button>
            ))}
          </section>

          <section className="panel compact">
            <div className="panel-title">
              <div>
                <small>ÁRBOL EXPLICABLE</small>
                <h2>Cómo decide ANA</h2>
              </div>
              <CircleHelp size={18}/>
            </div>
            <ol className="steps">
              <li><b>01</b> Identifica la actuación.</li>
              <li><b>02</b> Comprueba estructura.</li>
              <li><b>03</b> Comprueba protección.</li>
              <li><b>04</b> Propone una vía preliminar.</li>
            </ol>
          </section>
        </aside>

        <section className="chat-card">
          <div className="chat-header">
            <div className="ana-identity">
              <div className="ana-avatar"><Bot size={21}/><i /></div>
              <div>
                <b>ANA</b>
                <small>Motor orientador explicable</small>
              </div>
            </div>
            <span className={officer ? "role officer" : "role"}>{officer ? "Vista de control" : "Vista ciudadana"}</span>
          </div>

          <div className="messages">
            {messages.map((m, idx) => (
              <Message key={idx} message={m} officer={officer} onAudit={addAudit}/>
            ))}
          </div>

          <div className="composer-wrap">
            {file && (
              <div className="attachment">
                <FileText size={15}/>
                <span>{file.name} · {file.size}</span>
                <button onClick={() => setFile(null)}><X size={14}/></button>
              </div>
            )}
            <div className="composer">
              <label className="icon-button" title="Adjuntar documento">
                <Paperclip size={18}/>
                <input type="file" accept=".pdf,.doc,.docx,.txt" onChange={e => {
                  const f = e.target.files?.[0];
                  if (f) setFile({ name: f.name, size: `${(f.size / 1024).toFixed(1)} KB` });
                }}/>
              </label>
              <input
                id="composer"
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter") send(); }}
                placeholder="Describe la actuación u obra propuesta…"
              />
              <button className="icon-button" title="Entrada de voz"><Mic size={18}/></button>
              <button className="send-button" onClick={() => send()}><Send size={16}/> Analizar</button>
            </div>
            <small className="composer-note">La recomendación es orientativa y requiere comprobación administrativa formal.</small>
          </div>
        </section>

        <aside className="rightbar">
          <ResultPanel result={result}/>
          <AuditPanel audit={audit}/>
          <section className="info-card">
            <ShieldCheck size={20}/>
            <div>
              <b>Supervisión humana</b>
              <p>El prototipo muestra cómo una recomendación puede quedar explicada y trazada.</p>
            </div>
          </section>
        </aside>
      </main>

      <footer>
        <span>ANA · Demostrador conceptual e investigador de TFG</span>
        <span>Grado en Ciencias Políticas y de la Administración Pública · UAM</span>
      </footer>
    </div>
  );
}

function Message({ message, officer, onAudit }) {
  if (message.who === "user") {
    return (
      <div className="message-row user-row">
        <div className="bubble user-bubble">
          <p>{message.text}</p>
          {message.attachment && <small>📎 {message.attachment}</small>}
        </div>
        <div className="mini-avatar you">TÚ</div>
      </div>
    );
  }

  if (message.result) {
    const r = message.result;
    return (
      <div className="message-row">
        <div className="mini-avatar ana">A</div>
        <div className="bubble ana-bubble">
          {r.status === "insufficient" ? (
            <>
              <div className="bubble-heading warning-text"><AlertTriangle size={17}/> Necesito un dato más</div>
              <p>{r.reason}</p>
              <div className="question-grid">
                <div><b>01 · Estructura</b><span>¿Afecta a muros de carga, pilares, vigas, forjados o fachada?</span></div>
                <div><b>02 · Protección</b><span>¿El inmueble tiene protección patrimonial o está catalogado?</span></div>
              </div>
            </>
          ) : (
            <>
              <div className="result-mini-head">
                <div>
                  <small>ORIENTACIÓN PRELIMINAR</small>
                  <h3>{r.title}</h3>
                </div>
                <strong>{r.confidence}%</strong>
              </div>
              <p>{r.reason}</p>
              <div className="check-grid">
                {r.checks.map((c, i) => (
                  <div className={`check ${c[2]}`} key={i}>
                    {c[2] === "good" ? <Check size={14}/> : <Info size={14}/>}
                    <span><b>{c[0]}</b>{c[1]}</span>
                  </div>
                ))}
              </div>
              {officer && (
                <div className="officer-actions">
                  <small>SUPERVISIÓN HUMANA</small>
                  <div>
                    <button onClick={() => onAudit("VALIDACIÓN", "Verificación formal favorable")}>Validar</button>
                    <button onClick={() => onAudit("SUBSANACIÓN", "Falta aportar documentación")}>Subsanación</button>
                    <button onClick={() => onAudit("INSPECCIÓN", "Derivación a inspección urbanística")}>Inspección</button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="message-row">
      <div className="mini-avatar ana">A</div>
      <div className="bubble ana-bubble">
        <b>{message.text}</b>
        <p>{message.extra}</p>
        <div className="tip"><Info size={14}/><span>Empieza describiendo qué quieres modificar y si afecta a elementos estructurales.</span></div>
      </div>
    </div>
  );
}

function ResultPanel({ result }) {
  if (!result) {
    return (
      <section className="panel result-panel empty-result">
        <div className="panel-title"><div><small>RESULTADO</small><h2>Estado del análisis</h2></div><ClipboardCheck size={18}/></div>
        <div className="empty-state"><div>⌁</div><b>Aún no hay clasificación</b><span>El resultado aparecerá aquí después del análisis.</span></div>
      </section>
    );
  }

  if (result.status === "insufficient") {
    return (
      <section className="panel result-panel">
        <div className="panel-title"><div><small>RESULTADO</small><h2>Datos necesarios</h2></div><AlertTriangle size={18}/></div>
        <div className="result-warning"><AlertTriangle size={17}/><b>Información insuficiente</b></div>
        <p className="result-description">{result.reason}</p>
        <div className="side-checks">
          {result.checks.map((c, i) => <CheckLine key={i} item={c}/>)}
        </div>
      </section>
    );
  }

  return (
    <section className="panel result-panel">
      <div className="panel-title"><div><small>RESULTADO</small><h2>Estado del análisis</h2></div><ClipboardCheck size={18}/></div>
      <span className={`result-tag ${result.type}`}>RECOMENDACIÓN PRELIMINAR</span>
      <h3 className="big-result">{result.title}</h3>
      <p className="result-description">{result.reason}</p>

      <div className="confidence">
        <div><span>Nivel orientativo</span><b>{result.confidence}%</b></div>
        <div className="bar"><i className={result.type} style={{width:`${result.confidence}%`}}/></div>
      </div>

      <div className="side-checks">
        {result.checks.map((c, i) => <CheckLine key={i} item={c}/>)}
      </div>

      <div className="legal-note">
        <b>Importante</b>
        <span>La orientación no constituye una resolución administrativa firme.</span>
      </div>
    </section>
  );
}

function CheckLine({ item }) {
  const [name, text, type] = item;
  return (
    <div className={`side-check ${type}`}>
      {type === "good" ? <Check size={14}/> : type === "danger" ? <AlertTriangle size={14}/> : <Info size={14}/>}
      <span><b>{name}</b><small>{text}</small></span>
    </div>
  );
}

function AuditPanel({ audit }) {
  return (
    <section className="audit-panel">
      <div className="panel-title dark">
        <div><small>TRAZABILIDAD</small><h2>Audit trail</h2></div>
        <History size={18}/>
      </div>
      <span className="audit-count">{audit.length} {audit.length === 1 ? "decisión" : "decisiones"}</span>
      {audit.length === 0 ? (
        <p className="audit-empty">Las actuaciones del modo funcionario aparecerán aquí.</p>
      ) : (
        <div className="audit-list">
          {audit.map((a, i) => (
            <div className="audit-item" key={i}>
              <i/>
              <div><small>{a.time} · {a.session}</small><b>{a.action}</b><span>{a.reason}</span></div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

createRoot(document.getElementById("root")).render(<App />);
