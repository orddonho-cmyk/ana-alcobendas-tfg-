# ANA · Orientación urbanística asistida

Aplicación React + Vite basada en el prototipo TFG aportado.

## Ejecutar

```bash
npm install
npm run dev
```

Después abre la URL que muestre Vite.

## Producción

```bash
npm run build
npm run preview
```

## Nota

La clasificación sigue siendo un demostrador local basado en reglas. No consulta Catastro, PGOU, BIC ni bases municipales reales y no sustituye una resolución administrativa.
